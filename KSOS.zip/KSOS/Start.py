from time import sleep
import shutil
import random

print("KDOS -- KarpenDeveloper OS Version: 1.0")
print("Copiryting KarpenStudio -- Wellcom KDOS")
print("Console: Для помощи введите help")
cmd = input("Plase write your command: ")

if cmd == "help":
	print("Console: Помощь:")
	print("Commands: cd, cp")

elif cmd == "cp":
	print("Сonsole: Введите путь к каталогу: ")
	sourse = input(">>> ")
	print("Поиск каталога...")
	sleep(5)
	des = input("Console: Куда копируем: ")
	shutil.copyfile(sourse, des)
	print("Console: Файл успешно скопирован")

elif cmd == "cd":
	print("Console: Пожалуйста напишите путь до каталога.")
	cdm = input(">>> ")
	print("Console: Поиск вашего каталога...")
	sleep(5)
	cdr = random.radient(1, 2)
	if cdr == 1:
		print("Каталог найден и вы в нём")
		cmd = input("Plase write your command: ")
	elif cdr == 2:
		print("Сonsole Каталог не найден")

input("Pres enter to rebut system")

